import 'dart:typed_data';
import 'package:face_detection_tflite/face_detection_tflite.dart';
import 'embedding_utils.dart';
import 'face_pipeline.dart';
import 'face_repository.dart';
import 'models.dart';

class EnrollmentService {
  EnrollmentService({
    required FacePipeline pipeline,
    required FaceRepository repo,
    this.maxFacesPerImage = 1,
  })  : _pipeline = pipeline,
        _repo = repo;

  final FacePipeline _pipeline;
  final FaceRepository _repo;

  final int maxFacesPerImage;

  Future<int> enrollFaceFromImage({
    required Uint8List imageBytes,
    required String label,
    Map<String, dynamic>? meta,
    String? thumbnailPath,
    FaceDetectionMode mode = FaceDetectionMode.fast,
    List<Face>? detectedFaces,
  }) async {
    // Use provided detections when available (avoids duplicate work).
    var faces = detectedFaces ?? await _pipeline.detectFaces(imageBytes, mode: mode);

    // Retry with accurate mode if fast mode found nothing.
    if (faces.isEmpty && mode == FaceDetectionMode.fast) {
      faces = await _pipeline.detectFaces(imageBytes, mode: FaceDetectionMode.accurate);
    }

    if (faces.isEmpty) {
      throw StateError('No face detected. Please retake the photo with a clear face.');
    }

    // If multiple faces, pick the largest (most visible) — use BoundingBox.width/height.
    if (faces.length > maxFacesPerImage) {
      faces = List.of(faces)
        ..sort((a, b) =>
            (b.boundingBox.width * b.boundingBox.height)
                .compareTo(a.boundingBox.width * a.boundingBox.height));
    }

    final face = faces.first;
    final emb = await _pipeline.embeddingForFace(face, imageBytes);
    final blob = float32ToBytes(emb);

    final enrolled = EnrolledFace(
      label: label,
      embeddingBlob: blob,
      embeddingDim: emb.length,
      createdAtMs: DateTime.now().millisecondsSinceEpoch,
      thumbnailPath: thumbnailPath,
      meta: meta,
    );
    return _repo.insertFace(enrolled);
  }
}
