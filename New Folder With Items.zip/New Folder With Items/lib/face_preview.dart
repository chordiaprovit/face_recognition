import 'dart:async';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:face_detection_tflite/face_detection_tflite.dart';

class FacePreview extends StatefulWidget {
  final Uint8List imageBytes;
  final List<Face> faces;
  const FacePreview({super.key, required this.imageBytes, required this.faces});

  @override
  State<FacePreview> createState() => _FacePreviewState();
}

class _FacePreviewState extends State<FacePreview> {
  ui.Image? _image;

  @override
  void initState() {
    super.initState();
    _decodeImage();
  }

  Future<void> _decodeImage() async {
    final completer = Completer<ui.Image>();
    ui.decodeImageFromList(widget.imageBytes, (img) => completer.complete(img));
    final img = await completer.future;
    if (mounted) setState(() => _image = img);
  }

  @override
  Widget build(BuildContext context) {
    if (_image == null) {
      return const SizedBox(
        width: 200,
        height: 200,
        child: Center(child: CircularProgressIndicator()),
      );
    }

    final img = _image!;
    // Scale down large images to fit on screen
    const maxSize = 300.0;
    final scale = (img.width > maxSize || img.height > maxSize)
        ? maxSize / (img.width > img.height ? img.width : img.height)
        : 1.0;
    final displayW = img.width * scale;
    final displayH = img.height * scale;

    return SizedBox(
      width: displayW,
      height: displayH,
      child: Stack(
        fit: StackFit.expand,
        children: [
          RawImage(image: img, fit: BoxFit.fill),
          CustomPaint(
            painter: _BoxPainter(
              faces: widget.faces,
              imageWidth: img.width.toDouble(),
              imageHeight: img.height.toDouble(),
            ),
          ),
        ],
      ),
    );
  }
}

class _BoxPainter extends CustomPainter {
  final List<Face> faces;
  final double imageWidth;
  final double imageHeight;

  _BoxPainter({
    required this.faces,
    required this.imageWidth,
    required this.imageHeight,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.greenAccent
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0;

    final scaleX = size.width / imageWidth;
    final scaleY = size.height / imageHeight;

    for (final f in faces) {
      final bb = f.boundingBox;
      final rect = Rect.fromLTRB(
        bb.left * scaleX,
        bb.top * scaleY,
        bb.right * scaleX,
        bb.bottom * scaleY,
      );
      canvas.drawRect(rect, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
