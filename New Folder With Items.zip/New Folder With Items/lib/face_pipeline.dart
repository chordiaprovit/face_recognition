import 'dart:async';
import 'dart:typed_data';
import 'package:face_detection_tflite/face_detection_tflite.dart';

class FacePipeline {
  FacePipeline({FaceDetector? detector}) : _detector = detector ?? FaceDetector();
  final FaceDetector _detector;
  bool _initialized = false;

  /// Serializing lock — prevents concurrent native inference calls.
  Future<void> _lastOp = Future.value();

  Future<T> _runLocked<T>(Future<T> Function() fn) {
    final next = _lastOp.catchError((_) {}).then((_) => fn());
    _lastOp = next.then((_) {}).catchError((_) {});
    return next;
  }

  Future<void> initialize({
    FaceDetectionModel model = FaceDetectionModel.frontCamera,
  }) async {
    if (_initialized) return;
    await _runLocked(() => _detector.initialize(model: model));
    _initialized = true;
  }

  Future<void> dispose() async {
    if (!_initialized) return;
    _initialized = false;
    await _runLocked(() async => _detector.dispose());
  }

  Future<List<Face>> detectFaces(
    Uint8List imageBytes, {
    FaceDetectionMode mode = FaceDetectionMode.fast,
  }) async {
    if (!_initialized) throw StateError('FacePipeline not initialized');
    return _runLocked(() => _detector.detectFaces(imageBytes, mode: mode));
  }

  /// Returns a 192-dim embedding for the given face.
  /// Uses getFaceEmbedding() which is the correct async API.
  Future<List<double>> embeddingForFace(Face face, Uint8List imageBytes) async {
    if (!_initialized) throw StateError('FacePipeline not initialized');
    return _runLocked(() => _detector.getFaceEmbedding(face, imageBytes));
  }

  /// Cosine similarity between two embeddings (-1 to 1, higher = more similar).
  static double compare(List<double> a, List<double> b) =>
      FaceDetector().compareFaces(a, b);

  /// Euclidean distance between two embeddings (lower = more similar).
  static double distance(List<double> a, List<double> b) =>
      FaceDetector().faceDistance(a, b);
}
