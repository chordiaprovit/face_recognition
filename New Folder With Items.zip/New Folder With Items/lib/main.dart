
import 'dart:async';
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:face_detection_tflite/face_detection_tflite.dart';
import 'package:face_recognition/enrollment_service.dart';
import 'package:face_recognition/face_pipeline.dart';
import 'package:face_recognition/face_repository.dart';
import 'package:face_recognition/recognition_service.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:permission_handler/permission_handler.dart';
import 'widgets/face_preview.dart';


Future<void> main() async {
  try {
    WidgetsFlutterBinding.ensureInitialized();
    final cameras = await availableCameras();
    runApp(FaceApp(cameras: cameras));
  } catch (e) {
    runApp(ErrorApp(error: e.toString()));
  }
}

class ErrorApp extends StatelessWidget {
  final String error;
  const ErrorApp({super.key, required this.error});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error, size: 64, color: Colors.red),
                const SizedBox(height: 16),
                const Text('App Error', style: TextStyle(fontSize: 20)),
                const SizedBox(height: 8),
                Text(error, textAlign: TextAlign.center),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class FaceApp extends StatelessWidget {
  final List<CameraDescription> cameras;
  const FaceApp({super.key, required this.cameras});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: FaceScreen(cameras: cameras),
    );
  }
}

class FaceScreen extends StatefulWidget {
  final List<CameraDescription> cameras;
  const FaceScreen({super.key, required this.cameras});

  @override
  State<FaceScreen> createState() => _FaceScreenState();
}

class _FaceScreenState extends State<FaceScreen> {
  CameraController? _controller;
  String? _error;
  bool _busy = false;

    late final FacePipeline _pipeline;
    late final FaceRepository _repo;
    late final EnrollmentService _enroll;
    late final RecognitionService _recognize;

  String _status = 'Ready';
  String _matchLine = '';

  @override
  void initState() {
    super.initState();
    _pipeline = FacePipeline();
    _repo = FaceRepository();
    _enroll = EnrollmentService(pipeline: _pipeline, repo: _repo);
    _recognize = RecognitionService(pipeline: _pipeline, repo: _repo);

    _init();
  }

  Future<void> _init() async {
    try {
      final ok = await _requestCameraPermission();
      if (!ok) {
        setState(() => _error = 'Camera permission denied');
        return;
      }

      final back = widget.cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => widget.cameras.first,
      );

      _controller = CameraController(back, ResolutionPreset.medium, enableAudio: false);
      await _controller!.initialize();

      // MediaPipe/TFLite init
      await _pipeline.initialize(
        model: back.lensDirection == CameraLensDirection.front
            ? FaceDetectionModel.frontCamera
            : FaceDetectionModel.backCamera,
      );

      setState(() => _status = 'Initialized');
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  Future<bool> _requestCameraPermission() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  /// Capture a photo and fix EXIF/rotation so the image is always upright.
  /// Front-camera photos on Android/iOS are often saved rotated or mirrored,
  /// which causes face detectors to miss faces entirely.
  Future<Uint8List> _captureJpegBytes() async {
    final ctrl = _controller;
    if (ctrl == null || !ctrl.value.isInitialized) {
      throw StateError('Camera not ready');
    }
    final file = await ctrl.takePicture();
    final raw = await file.readAsBytes();

    // Decode and auto-rotate based on EXIF orientation tag, then re-encode.
    // This is the most reliable way to ensure faces appear upright to the model.
    final decoded = img.decodeImage(raw);
    if (decoded == null) return raw; // fallback: return original bytes
    final oriented = img.bakeOrientation(decoded);
    return Uint8List.fromList(img.encodeJpg(oriented, quality: 92));
  }

  Future<void> _onEnroll() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _status = 'Capturing...';
      _matchLine = '';
    });

    try {
      final bytes = await _captureJpegBytes();

      // Detect faces first — bail early if none found.
      setState(() => _status = 'Detecting face...');
      var faces = await _pipeline.detectFaces(bytes);

      // Retry with more accurate mode if fast mode found nothing.
      if (faces.isEmpty) {
        faces = await _pipeline.detectFaces(bytes, mode: FaceDetectionMode.accurate);
      }

      if (faces.isEmpty) {
        setState(() => _status = 'No face detected. Please retake with a clear face.');
        return;
      }

      // Show preview with detected face boxes. Returns true = OK, false/null = Cancel.
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Detected face'),
          content: SingleChildScrollView(child: FacePreview(imageBytes: bytes, faces: faces)),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('OK')),
          ],
        ),
      );

      if (confirmed != true) {
        setState(() => _status = 'Enrollment cancelled');
        return;
      }

      final label = await _askLabel();
      if (label == null || label.trim().isEmpty) {
        setState(() => _status = 'Enrollment cancelled');
        return;
      }

      setState(() => _status = 'Detecting + embedding...');
      // Pass already-detected faces to skip redundant detection.
      final id = await _enroll.enrollFaceFromImage(imageBytes: bytes, label: label.trim(), detectedFaces: faces);

      setState(() => _status = 'Enrolled: $label (id=$id)');
    } catch (e) {
      setState(() => _status = 'Enroll failed: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _onRecognize() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _status = 'Capturing...';
      _matchLine = '';
    });

    try {
      final bytes = await _captureJpegBytes();

      // Show preview with boxes for user feedback.
      setState(() => _status = 'Detecting face...');
      var faces = await _pipeline.detectFaces(bytes);
      if (faces.isEmpty) {
        faces = await _pipeline.detectFaces(bytes, mode: FaceDetectionMode.accurate);
      }

      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(faces.isEmpty ? 'No face detected' : 'Detected face(s)'),
          content: SingleChildScrollView(child: FacePreview(imageBytes: bytes, faces: faces)),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
        ),
      );

      if (faces.isEmpty) {
        setState(() => _status = 'No face detected. Please retake with a clear face.');
        return;
      }

      setState(() => _status = 'Recognizing...');

      final res = await _recognize.recognizeFromImage(imageBytes: bytes);

      if (!res.matched || res.bestMatch == null) {
        setState(() {
          _status = 'No match';
          _matchLine = 'distance=${res.bestDistance.toStringAsFixed(3)}  sim=${res.bestSimilarity.toStringAsFixed(3)}';
        });
      } else {
        setState(() {
          _status = 'Matched: ${res.bestMatch!.label}';
          _matchLine = 'distance=${res.bestDistance.toStringAsFixed(3)}  sim=${res.bestSimilarity.toStringAsFixed(3)}';
        });
      }
    } catch (e) {
      setState(() => _status = 'Recognize failed: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<String?> _askLabel() async {
    final controller = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Enroll label'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: 'e.g. User123'),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('Save')),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller?.dispose();
    _pipeline.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final err = _error;
    if (err != null) return ErrorApp(error: err);

    final ctrl = _controller;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Face Enroll + Recognize (SQLite + MediaPipe/TFLite)'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ctrl == null || !ctrl.value.isInitialized
                ? const Center(child: CircularProgressIndicator())
                : ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: CameraPreview(ctrl),
                  ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Text(_status, style: const TextStyle(fontSize: 16)),
                if (_matchLine.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(_matchLine, style: const TextStyle(fontSize: 12, color: Colors.white70)),
                ],
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _busy ? null : _onEnroll,
                        icon: const Icon(Icons.person_add),
                        label: const Text('Enroll'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _busy ? null : _onRecognize,
                        icon: const Icon(Icons.face),
                        label: const Text('Recognize'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _busy
                            ? null
                            : () async {
                                final faces = await _repo.getAllFaces();
                                setState(() => _status = 'Enrolled faces: ${faces.length}');
                              },
                        icon: const Icon(Icons.list),
                        label: const Text('List enrolled'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
