
import 'dart:math' as math;
import 'dart:typed_data';

/// Store embeddings as Float32List in SQLite BLOB.
/// This avoids JSON bloat and is fast to load.
Uint8List float32ToBytes(List<double> v) {
  final f32 = Float32List(v.length);
  for (var i = 0; i < v.length; i++) {
    f32[i] = v[i].toDouble();
  }
  return f32.buffer.asUint8List();
}

Float32List bytesToFloat32(Uint8List blob) => blob.buffer.asFloat32List();

double euclideanDistance(Float32List a, Float32List b) {
  if (a.length != b.length) {
    throw ArgumentError('Embedding dims mismatch: ${a.length} vs ${b.length}');
  }
  double sum = 0.0;
  for (var i = 0; i < a.length; i++) {
    final d = a[i] - b[i];
    sum += d * d;
  }
  return math.sqrt(sum);
}

double cosineSimilarity(Float32List a, Float32List b) {
  if (a.length != b.length) {
    throw ArgumentError('Embedding dims mismatch: ${a.length} vs ${b.length}');
  }
  double dot = 0.0, na = 0.0, nb = 0.0;
  for (var i = 0; i < a.length; i++) {
    final x = a[i], y = b[i];
    dot += x * y;
    na += x * x;
    nb += y * y;
  }
  final denom = math.sqrt(na) * math.sqrt(nb);
  if (denom == 0) return 0.0;
  return dot / denom;
}
