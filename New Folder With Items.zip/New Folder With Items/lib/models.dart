
import 'dart:convert';
import 'dart:typed_data';

class EnrolledFace {
  final int? id;
  final String label; // e.g., name/userId
  final Uint8List embeddingBlob; // Float32List bytes
  final int embeddingDim;
  final int createdAtMs;
  final String? thumbnailPath; // optional local file path
  final Map<String, dynamic>? meta; // JSON-ish (store as TEXT)

  EnrolledFace({
    this.id,
    required this.label,
    required this.embeddingBlob,
    required this.embeddingDim,
    required this.createdAtMs,
    this.thumbnailPath,
    this.meta,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'label': label,
        'embedding': embeddingBlob,
        'embedding_dim': embeddingDim,
        'created_at_ms': createdAtMs,
        'thumbnail_path': thumbnailPath,
        'meta_json': meta == null ? null : _encodeJson(meta!),
      };

  static EnrolledFace fromMap(Map<String, Object?> map) => EnrolledFace(
        id: map['id'] as int?,
        label: map['label'] as String,
        embeddingBlob: map['embedding'] as Uint8List,
        embeddingDim: map['embedding_dim'] as int,
        createdAtMs: map['created_at_ms'] as int,
        thumbnailPath: map['thumbnail_path'] as String?,
        meta: map['meta_json'] == null ? null : _decodeJson(map['meta_json'] as String),
      );

  static String _encodeJson(Map<String, dynamic> obj) => jsonEncode(obj);
  static Map<String, dynamic> _decodeJson(String s) => (jsonDecode(s) as Map).cast<String, dynamic>();
}

class RecognitionLogEntry {
  final int? id;
  final int? matchedFaceId;
  final String? matchedLabel;
  final double distance;
  final double similarity; // optional (if you use cosine)
  final int tsMs;

  RecognitionLogEntry({
    this.id,
    required this.matchedFaceId,
    required this.matchedLabel,
    required this.distance,
    required this.similarity,
    required this.tsMs,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'matched_face_id': matchedFaceId,
        'matched_label': matchedLabel,
        'distance': distance,
        'similarity': similarity,
        'ts_ms': tsMs,
      };

  static RecognitionLogEntry fromMap(Map<String, Object?> map) => RecognitionLogEntry(
        id: map['id'] as int?,
        matchedFaceId: map['matched_face_id'] as int?,
        matchedLabel: map['matched_label'] as String?,
        distance: (map['distance'] as num).toDouble(),
        similarity: (map['similarity'] as num).toDouble(),
        tsMs: map['ts_ms'] as int,
      );
}
