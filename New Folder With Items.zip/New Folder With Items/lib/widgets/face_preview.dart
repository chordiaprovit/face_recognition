import 'dart:async';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:face_detection_tflite/face_detection_tflite.dart';

class FacePreview extends StatefulWidget {
  final Uint8List imageBytes;
  final List<Face> faces;
  const FacePreview({super.key, required this.imageBytes, required this.faces});

  @override
  State<FacePreview> createState() => _FacePreviewState();
}

class _FacePreviewState extends State<FacePreview> {
  ui.Image? _image;

  @override
  void initState() {
    super.initState();
    _decodeImage();
  }

  Future<void> _decodeImage() async {
    final completer = Completer<ui.Image>();
    ui.decodeImageFromList(widget.imageBytes, (img) => completer.complete(img));
    final img = await completer.future;
    if (mounted) setState(() => _image = img);
  }

  @override
  Widget build(BuildContext context) {
    if (_image == null) return const SizedBox(width: 200, height: 200, child: Center(child: CircularProgressIndicator()));

    final img = _image!;
    return SizedBox(
      width: img.width.toDouble(),
      height: img.height.toDouble(),
      child: Stack(
        fit: StackFit.expand,
        children: [
          RawImage(image: img, fit: BoxFit.contain),
          CustomPaint(
            painter: _BoxPainter(faces: widget.faces, imageWidth: img.width.toDouble(), imageHeight: img.height.toDouble()),
          ),
        ],
      ),
    );
  }
}

class _BoxPainter extends CustomPainter {
  final List<Face> faces;
  final double imageWidth;
  final double imageHeight;
  _BoxPainter({required this.faces, required this.imageWidth, required this.imageHeight});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.greenAccent
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.0;

    for (final f in faces) {
      final bb = f.boundingBox;
      // Determine if bbox is normalized (0..1) or absolute pixels (>1)
      final left = (bb.left <= 1.01) ? bb.left * imageWidth : bb.left;
      final top = (bb.top <= 1.01) ? bb.top * imageHeight : bb.top;
      final right = (bb.right <= 1.01) ? bb.right * imageWidth : bb.right;
      final bottom = (bb.bottom <= 1.01) ? bb.bottom * imageHeight : bb.bottom;

      final rect = Rect.fromLTWH(left, top, (right - left), (bottom - top));
      canvas.drawRect(rect, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
